#!/usr/bin/env python
# -*- coding: utf-8 -*-

import urllib, urllib2, os, re, sys
import urlresolver, xbmc, xbmcaddon, xbmcgui, xbmcplugin
import dataparser

file = os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'OPCIONES.xml')

opciones = open(file, "r+")
contenido = opciones.read()


def CARPETAS():
    xbmc.executebuiltin("Container.SetViewMode(500)")
    dialog = xbmcgui.Dialog()
    matches = dataparser.etiqueta_maestra(contenido, "<CARPETA>(.*?)</CARPETA>")
    for item in matches:
        NOMBRE = dataparser.subetiqueta(item, "<NOMBRE>(.*?)</NOMBRE>")
        IMAGEN = dataparser.subetiqueta(item, "<IMAGEN>(.*?)</IMAGEN>")
        LINK = dataparser.subetiqueta(item, "<LINK>(.*?)</LINK>")
        CONTENIDO = dataparser.subetiqueta(item, "<CONTENIDO>(.*?)</CONTENIDO>")
        TIPO = dataparser.subetiqueta(item, "<TIPO>(.*?)</TIPO>")
        if TIPO.upper() == "XML" and CONTENIDO.upper() == "VIDEO":
            MODO = 1
        elif TIPO.upper() == "PLX" and CONTENIDO.upper() == "VIDEO":
            MODO = 2
        elif TIPO.upper() == "XML" and CONTENIDO.upper() == "TV":
            MODO = 3
        elif TIPO.upper() == "PLX" and CONTENIDO.upper() == "TV":
            MODO = 4
        else:
            dialog.ok('ERROR', 'Revisa que tus etiquetas <TIPO>', 'y <CONTENIDO> sean correctas.')
            sys.exit()
            
        addDir(NOMBRE, LINK, MODO, IMAGEN)
    xbmc.executebuiltin("Container.SetViewMode(500)")
        
                                  
def LISTADO_xml(url):  # MODE 1   
    req = urllib2.Request(url)
    # req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    matches = dataparser.etiqueta_maestra(link, "<item>(.*?)</item>")
    for item in matches:
        NOMBRE = dataparser.subetiqueta(item, "<title>(.*?)</title>")
        IMAGEN = dataparser.subetiqueta(item, "<thumbnail>(.*?)</thumbnail>")
        LINK = dataparser.subetiqueta(item, "<link>(.*?)</link>")
        addDir(NOMBRE, LINK, 20, IMAGEN)
    xbmc.executebuiltin("Container.SetViewMode(500)")

        
def LISTADO_plx(url):  # MODE 2
    req = urllib2.Request(url)
    # req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    match_date = re.compile('\n# .+?\ntype=video\nname=(.+?)\nthumb=(.+?)\ndate=.+?\nURL=(.+?)\n').findall(link)
    match_without = re.compile('\n# .+?\ntype=video\nname=(.+?)\nthumb=(.+?)\nURL=(.+?)\n').findall(link)
    match_without2 = re.compile('\n# .+?\r\ntype=video\r\nname=(.+?)\r\nthumb=(.+?)\r\nURL=(.+?)\r').findall(link)
    for name, thumbnail, url in match_date:
        addDir(name, url, 20, thumbnail)
    for name, thumbnail, url in match_without:
        addDir(name, url, 20, thumbnail)
    for name, thumbnail, url in match_without2:
        addDir(name, url, 20, thumbnail)
    xbmc.executebuiltin("Container.SetViewMode(500)")
    

def LISTADO_TV_xml(url):  # MODE 3   
    req = urllib2.Request(url)
    # req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    matches = dataparser.etiqueta_maestra(link, "<item>(.*?)</item>")
    for item in matches:
        NOMBRE = dataparser.subetiqueta(item, "<title>(.*?)</title>")
        IMAGEN = dataparser.subetiqueta(item, "<thumbnail>(.*?)</thumbnail>")
        LINK = dataparser.subetiqueta(item, "<link>(.*?)</link>")
        addDir(NOMBRE, LINK, 30, IMAGEN)
    xbmc.executebuiltin("Container.SetViewMode(500)")


def LISTADO_TV_plx(url):  # MODE 4
    req = urllib2.Request(url)
    # req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    match_date = re.compile('\n# .+?\ntype=video\nname=(.+?)\nthumb=(.+?)\ndate=.+?\nURL=(.+?)\n').findall(link)
    match_without = re.compile('\n# .+?\ntype=video\nname=(.+?)\nthumb=(.+?)\nURL=(.+?)\n').findall(link)
    match_without2 = re.compile('\n# .+?\r\ntype=video\r\nname=(.+?)\r\nthumb=(.+?)\r\nURL=(.+?)\r').findall(link)
    for name, thumbnail, url in match_date:
        addDir(name, url, 30, thumbnail)
    for name, thumbnail, url in match_without:
        addDir(name, url, 30, thumbnail)
    for name, thumbnail, url in match_without2:
        addDir(name, url, 30, thumbnail)
    xbmc.executebuiltin("Container.SetViewMode(500)")


def VIDEOS(url, name):  # MODE 20
    player = xbmc.Player()
    player.play(urlresolver.resolve(url))
    CARPETAS()
        
def TVCH(url, name):  # MODE 30        
    player = xbmc.Player()
    player.play(url)
    CARPETAS()
    
    
    
        

               
def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params)-1]=='/'):
            params = params[0:len(params)-2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
                            
    return param
    



def addLink(name, url, iconimage):
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage = iconimage)
    xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = str(url), listitem = liz, isFolder=False)


def addDir(name, url, mode, iconimage):
    u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name)
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage = iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = str(u), listitem = liz, isFolder=True)


             
params = get_params()
url = None
name = None
mode = None

try:
        url = urllib.unquote_plus(params["url"])
except:
        pass
try:
        name = urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode = int(params["mode"])
except:
        pass


print "Mode: " + str(mode)
print "URL: " + str(url)
print "Name: " + str(name)


if mode == None or url == None or len(url) < 1:
        print ""
        CARPETAS()
       
elif mode == 1:
        print "" + url
        LISTADO_xml(url)
        
elif mode == 2:
        print "" + url
        LISTADO_plx(url)
        
elif mode == 3:
        print "" + url
        LISTADO_TV_xml(url)
        
elif mode == 4:
        print "" + url
        LISTADO_TV_plx(url)
        
elif mode == 20:
        print "" + url
        VIDEOS(url, name)

elif mode == 30:
        print "" + url
        TVCH(url, name)


xbmcplugin.endOfDirectory(int(sys.argv[1]))

plugin.video.pulsar
===================

Pulsar addon for XBMC
